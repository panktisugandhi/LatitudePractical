package com.pankti.latitudepractical.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.pankti.latitudepractical.R;
import com.pankti.latitudepractical.db.DatabaseHandler;
import com.pankti.latitudepractical.model.Student;

public class GradeEntryFragment extends Fragment implements View.OnClickListener {


    private EditText etName, etGrade, etDuration, etFees;
    private Spinner spStandard;
    private Button btnSubmit;
    private DatabaseHandler db;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        db = new DatabaseHandler(getActivity());

        View root = inflater.inflate(R.layout.fragment_grade_entry, container, false);

        etName = root.findViewById(R.id.etName);
        etGrade = root.findViewById(R.id.etGrade);
        etDuration = root.findViewById(R.id.etDuration);
        etFees = root.findViewById(R.id.etFees);
        spStandard = root.findViewById(R.id.spStandard);
        btnSubmit = root.findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(this);

        return root;
    }

    public void addData(String name, String standard, String grade, String duration, String fees) {
        boolean insertData = db.addStudent(new Student(name, standard, grade, duration, fees));

        if (insertData) {
            Toast.makeText(getActivity(), "Data Successfully Inserted!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getActivity(), "Something went wrong", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onClick(View v) {
        if (etName.getText().toString().isEmpty()) {
            Toast.makeText(getActivity(), "Enter Name", Toast.LENGTH_SHORT).show();
        } else if (etGrade.getText().toString().isEmpty()) {
            Toast.makeText(getActivity(), "Enter Grad", Toast.LENGTH_SHORT).show();
        } else if (etDuration.getText().toString().isEmpty()) {
            Toast.makeText(getActivity(), "Enter Duration", Toast.LENGTH_SHORT).show();
        } else if (etFees.getText().toString().isEmpty()) {
            Toast.makeText(getActivity(), "Enter Fees", Toast.LENGTH_SHORT).show();
        } else {
            String strName = etName.getText().toString();
            String strGrade = etGrade.getText().toString();
            String strDuration = etDuration.getText().toString();
            String strFees = etFees.getText().toString();
            String strStandard = spStandard.getSelectedItem().toString();
            Toast.makeText(getActivity(), strName + strGrade + strDuration + strFees + strStandard, Toast.LENGTH_SHORT).show();
            addData(strName, strStandard, strGrade, strDuration, strFees);
        }
    }
}