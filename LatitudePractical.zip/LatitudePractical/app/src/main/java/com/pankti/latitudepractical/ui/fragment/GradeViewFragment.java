package com.pankti.latitudepractical.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.pankti.latitudepractical.R;
import com.pankti.latitudepractical.db.DatabaseHandler;
import com.pankti.latitudepractical.model.Student;
import com.pankti.latitudepractical.ui.adapter.StudentListAdapter;

import java.util.ArrayList;

public class GradeViewFragment extends Fragment {

    private RecyclerView rcView;
    private DatabaseHandler databaseHandler;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_grade_view, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rcView = view.findViewById(R.id.rcView);
        databaseHandler = new DatabaseHandler(getActivity());
        displayStudents();
    }


    public void displayStudents() {
        ArrayList<Student> arrayList = new ArrayList<>(databaseHandler.getAllStudent());

        if (arrayList.isEmpty()) {
            Toast.makeText(getActivity(), "No Data Found", Toast.LENGTH_SHORT).show();
            return;
        }
        rcView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        rcView.setItemAnimator(new DefaultItemAnimator());
        StudentListAdapter adapter = new StudentListAdapter(getContext(), getActivity(), arrayList);
        rcView.setAdapter(adapter);
    }
}