package com.pankti.latitudepractical.ui.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pankti.latitudepractical.R;
import com.pankti.latitudepractical.model.Student;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class StudentListAdapter extends RecyclerView.Adapter<StudentListAdapter.ViewHolder> {

    private Context context;
    private Activity activity;
    private ArrayList<Student> arrayList;

    public StudentListAdapter(Context context, Activity activity, ArrayList<Student> arrayList) {
        this.context = context;
        this.activity = activity;
        this.arrayList = arrayList;
    }

    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_student, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Student student = arrayList.get(position);
        holder.id.setText(String.valueOf(student.id));
        holder.name.setText(student.name);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView id, name;

        public ViewHolder(View itemView) {
            super(itemView);
            id = (TextView) itemView.findViewById(R.id.tvid);
            name = (TextView) itemView.findViewById(R.id.tvName);
        }
    }
}
