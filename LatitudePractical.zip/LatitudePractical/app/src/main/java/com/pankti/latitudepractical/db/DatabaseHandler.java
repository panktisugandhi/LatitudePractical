package com.pankti.latitudepractical.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.pankti.latitudepractical.model.Student;

import java.util.ArrayList;

public class DatabaseHandler extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "StudentGrade";
    private static final String TABLE_GRADE = "StudentGradelist";
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_STANDARD = "Standard";
    private static final String KEY_GRADE = "Grade";
    private static final String KEY_DURATION = "Duration";
    private static final String KEY_FEES = "Fees";

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_GRADE_TABLE = "CREATE TABLE " + TABLE_GRADE + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_NAME + " TEXT,"
                + KEY_STANDARD + " TEXT," + KEY_GRADE + " TEXT," + KEY_DURATION + " TEXT," +
                KEY_FEES + " TEXT" + ")";
        db.execSQL(CREATE_GRADE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GRADE);

        // Create tables again
        onCreate(db);
    }

    // code to add the new contact
    public boolean addStudent(Student student) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, student.name);
        values.put(KEY_STANDARD, student.standard);
        values.put(KEY_GRADE, student.grade);
        values.put(KEY_DURATION, student.duration);
        values.put(KEY_FEES, student.fees);

        // Inserting Row
        db.insert(TABLE_GRADE, null, values);
        boolean createSuccessful = db.insert(TABLE_GRADE, null, values) > 0;
        db.close(); // Closing database connection
        return createSuccessful;
    }

    public ArrayList<Student> getAllStudent() {
        ArrayList<Student> array_list = new ArrayList<Student>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM " + TABLE_GRADE, null);
        res.moveToFirst();

        while (!res.isAfterLast()) {
            Student student = new Student();
            student.id = res.getInt(res.getColumnIndex(KEY_ID));
            student.name = res.getString(res.getColumnIndex(KEY_NAME));
            student.standard = res.getString(res.getColumnIndex(KEY_STANDARD));
            student.grade = res.getString(res.getColumnIndex(KEY_GRADE));
            student.duration = res.getString(res.getColumnIndex(KEY_DURATION));
            student.fees = res.getString(res.getColumnIndex(KEY_FEES));

            array_list.add(student);
            res.moveToNext();
        }
        return array_list;
    }

    public ArrayList<Student> getStudentListById(int id) {
        ArrayList<Student> array_list = new ArrayList<Student>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM " + TABLE_GRADE + " WHERE " + KEY_ID + " = " + id, null);
        res.moveToFirst();

        while (!res.isAfterLast()) {
            Student student = new Student();
            student.id = res.getInt(res.getColumnIndex(KEY_ID));
            student.name = res.getString(res.getColumnIndex(KEY_NAME));
            student.standard = res.getString(res.getColumnIndex(KEY_STANDARD));
            student.grade = res.getString(res.getColumnIndex(KEY_GRADE));
            student.duration = res.getString(res.getColumnIndex(KEY_DURATION));
            student.fees = res.getString(res.getColumnIndex(KEY_FEES));

            array_list.add(student);
            res.moveToNext();
        }
        return array_list;
    }

    public ArrayList<Student> getStudentListByStandard(String standard) {
        ArrayList<Student> array_list = new ArrayList<Student>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM " + TABLE_GRADE + " WHERE " + KEY_STANDARD + " = " + standard, null);
        res.moveToFirst();

        while (!res.isAfterLast()) {
            Student student = new Student();
            student.id = res.getInt(res.getColumnIndex(KEY_ID));
            student.name = res.getString(res.getColumnIndex(KEY_NAME));
            student.standard = res.getString(res.getColumnIndex(KEY_STANDARD));
            student.grade = res.getString(res.getColumnIndex(KEY_GRADE));
            student.duration = res.getString(res.getColumnIndex(KEY_DURATION));
            student.fees = res.getString(res.getColumnIndex(KEY_FEES));

            array_list.add(student);
            res.moveToNext();
        }
        return array_list;
    }
}

