package com.pankti.latitudepractical.model;

public class Student {
    public int id;
    public String name;
    public String standard;
    public String grade;
    public String duration;
    public String fees;

    public Student() {
    }

    public Student(String name, String standard, String grade, String duration, String fees) {
        this.name = name;
        this.standard = standard;
        this.grade = grade;
        this.duration = duration;
        this.fees = fees;
    }
}
