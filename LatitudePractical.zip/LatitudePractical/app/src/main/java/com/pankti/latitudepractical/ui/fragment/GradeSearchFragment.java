package com.pankti.latitudepractical.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.pankti.latitudepractical.R;
import com.pankti.latitudepractical.db.DatabaseHandler;
import com.pankti.latitudepractical.model.Student;
import com.pankti.latitudepractical.ui.adapter.StudentListAdapter;

import java.util.ArrayList;

public class GradeSearchFragment extends Fragment implements RadioGroup.OnCheckedChangeListener, View.OnClickListener {

    private RecyclerView rcView;
    private AppCompatRadioButton rbId;
    private AppCompatRadioButton rbStandard;
    private RadioGroup rgGroup;
    private DatabaseHandler databaseHandler;
    private AppCompatEditText etId;
    private AppCompatSpinner spStandard;
    private AppCompatButton btnSearch;
    private ArrayList<Student> arrayList;
    private StudentListAdapter adapter;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_grade_search, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rcView = view.findViewById(R.id.rcSearchView);
        rbId = view.findViewById(R.id.rbId);
        rbStandard = view.findViewById(R.id.rbStandard);
        rgGroup = view.findViewById(R.id.rgGroup);
        etId = view.findViewById(R.id.etId);
        spStandard = view.findViewById(R.id.spStandard);
        btnSearch = view.findViewById(R.id.btnSearch);
        btnSearch.setOnClickListener(this);
        rgGroup.setOnCheckedChangeListener(this);
        databaseHandler = new DatabaseHandler(getActivity());
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        int selectedId = group.getCheckedRadioButtonId();
        if (selectedId == rbId.getId()) {
            spStandard.setVisibility(View.GONE);
            etId.setVisibility(View.VISIBLE);
        } else {
            etId.setVisibility(View.GONE);
            spStandard.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onClick(View v) {
        int selectedId = rgGroup.getCheckedRadioButtonId();
        String searchValue;
        if (arrayList != null) {
            arrayList.clear();
        }
        if (adapter != null){
            adapter.notifyDataSetChanged();
        }
        if (selectedId == rbId.getId()) {
            if (etId.getText().toString().isEmpty()) {
                Toast.makeText(getActivity(), "Enter ID", Toast.LENGTH_SHORT).show();
                return;
            }
            searchValue = etId.getText().toString();
            arrayList = databaseHandler.getStudentListById(Integer.parseInt(searchValue));

        } else {
            searchValue = spStandard.getSelectedItem().toString();
            arrayList = databaseHandler.getStudentListByStandard(searchValue);
        }
        displayStudents();
    }

    public void displayStudents() {

        if (arrayList.isEmpty()) {
            Toast.makeText(getActivity(), "No Data Found", Toast.LENGTH_SHORT).show();
            return;
        }
        rcView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        rcView.setItemAnimator(new DefaultItemAnimator());
        adapter = new StudentListAdapter(getContext(), getActivity(), arrayList);
        rcView.setAdapter(adapter);
    }
}